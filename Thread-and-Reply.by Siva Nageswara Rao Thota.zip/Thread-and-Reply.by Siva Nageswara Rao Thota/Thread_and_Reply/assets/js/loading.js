  //paste this code under head tag or in a seperate js file.
  // Wait for window load
  
  $(document).ready( function() {
     setTimeout('$("#se_pre").hide()',1500);
    });
